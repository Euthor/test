CREATE FUNCTION [dbo].[getContaminators](@contaminatorsJsonVar NVARCHAR(MAX))
	RETURNS NVARCHAR(MAX)
	AS
	BEGIN
		DECLARE  @tempVar1 NVARCHAR(MAX) =''
		,@tempVar2 NVARCHAR(MAX) =''
		,@tempVar3 INT
		,@contaminatorsLeftVar NVARCHAR(MAX) =''
		,@resultVar NVARCHAR(MAX) =''
		,@counterVar INT = 1 
	
	SET @contaminatorsLeftVar = @contaminatorsJsonVar
	SET @tempVar2 = SUBSTRING(@contaminatorsJsonVar,0,charindex('{',@contaminatorsJsonVar))
	
	WHILE LEN(@contaminatorsJsonVar) > (LEN('"contaminators":[')+ 1) AND LEN(@tempVar2) < LEN(@contaminatorsJsonVar)
	BEGIN		
		SET @tempVar1 = SUBSTRING(@contaminatorsLeftVar,CHARINDEX('{',@contaminatorsLeftVar),CHARINDEX('}',@contaminatorsLeftVar)-CHARINDEX('{',@contaminatorsLeftVar)+1)
		SET @tempVar3 = CAST(SUBSTRING(@tempVar1, CHARINDEX(':',@tempVar1)+1,CHARINDEX(',"',@tempVar1)-CHARINDEX(':',@tempVar1)-1) AS INT)
		SET @resultVar = CONCAT(@resultVar,(SELECT CASE
													WHEN idCustomerType = 1 THEN CONCAT([idInternalCustomer], ' - ',firstName,' ',IIF(ISNULL(maidenName,'')='','',CONCAT(maidenName,' ')),lastName,' - ',SUBSTRING([riskReport], CHARINDEX('"global":{"score":', [riskReport])+18, (LEN([riskReport]) - CHARINDEX('"global":{"score":', [riskReport])-19)), ' risk points')
													WHEN idCustomerType = 2 THEN CONCAT([idInternalCustomer], ' - ',registeredName,' - ',SUBSTRING([riskReport], CHARINDEX('"global":{"score":', [riskReport])+18, (LEN([riskReport]) - CHARINDEX('"global":{"score":', [riskReport])-19)), ' risk points')
													END 
											FROM [eucomply].[dbo].[customer]
													LEFT JOIN [eucomply].[dbo].customerperson ON [eucomply].[dbo].customer.idCustomer = [eucomply].[dbo].customerperson.idCustomer
													LEFT JOIN [eucomply].[dbo].customerorganization ON [eucomply].[dbo].customer.idCustomer = [eucomply].[dbo].customerorganization.idCustomer
													LEFT JOIN [eucomply].[dbo].[incorporationtype] ON [eucomply].[dbo].customerorganization.idIncorporationType =  [eucomply].[dbo].[incorporationtype].idIncorporationType
													LEFT JOIN [eucomply].[dbo].lastRiskReport ON [eucomply].[dbo].customer.idCustomer = [eucomply].[dbo].[lastRiskReport].idCustomer 
													WHERE [eucomply].[dbo].[customer].[idCustomer] = @tempVar3),'<BR />')
		
		
		SET @tempVar2 = CONCAT(@tempVar2,@tempVar1,',')
		SET @contaminatorsLeftVar = SUBSTRING(@contaminatorsLeftVar,CHARINDEX(',{',@contaminatorsLeftVar)+1,LEN(@contaminatorsLeftVar)-CHARINDEX(',{',@contaminatorsLeftVar))
		SET @counterVar = @counterVar + 1
	END

	RETURN @resultVar
	END