/****** Script to hide euCOMPLY reports  ******/
  update [ReportServer$SQLEXPRESS].[dbo].[Catalog] 
	set hidden = 1
	WHERE LEFT(Name,6) = 'hidden'