UPDATE [eucomply].[dbo].[country] SET [name] = 'Korea (North)' ,riskFactor = 9 WHERE idCountry = 1
UPDATE [eucomply].[dbo].[country] SET [name] = 'Somalia' ,riskFactor = 4 WHERE idCountry = 2
UPDATE [eucomply].[dbo].[country] SET [name] = 'Afghanistan' ,riskFactor = 7 WHERE idCountry = 3
UPDATE [eucomply].[dbo].[country] SET [name] = 'Sudan' ,riskFactor = 4 WHERE idCountry = 4
UPDATE [eucomply].[dbo].[country] SET [name] = 'South Sudan' ,riskFactor = 6 WHERE idCountry = 5
UPDATE [eucomply].[dbo].[country] SET [name] = 'Iraq' ,riskFactor = 4 WHERE idCountry = 6
UPDATE [eucomply].[dbo].[country] SET [name] = 'Turkmenistan' ,riskFactor = 3 WHERE idCountry = 7
UPDATE [eucomply].[dbo].[country] SET [name] = 'Venezuela' ,riskFactor = 4 WHERE idCountry = 8
UPDATE [eucomply].[dbo].[country] SET [name] = 'Haiti' ,riskFactor = 6 WHERE idCountry = 9
UPDATE [eucomply].[dbo].[country] SET [name] = 'Myanmar' ,riskFactor = 7 WHERE idCountry = 10
UPDATE [eucomply].[dbo].[country] SET [name] = 'Uzbekistan' ,riskFactor = 3 WHERE idCountry = 11
UPDATE [eucomply].[dbo].[country] SET [name] = 'Angola' ,riskFactor = 3 WHERE idCountry = 12
UPDATE [eucomply].[dbo].[country] SET [name] = 'Libya' ,riskFactor = 4 WHERE idCountry = 13
UPDATE [eucomply].[dbo].[country] SET [name] = 'Burundi' ,riskFactor = 4 WHERE idCountry = 14
UPDATE [eucomply].[dbo].[country] SET [name] = 'Yemen' ,riskFactor = 7 WHERE idCountry = 15
UPDATE [eucomply].[dbo].[country] SET [name] = 'Cambodia' ,riskFactor = 6 WHERE idCountry = 16
UPDATE [eucomply].[dbo].[country] SET [name] = 'Chad' ,riskFactor = 3 WHERE idCountry = 17
UPDATE [eucomply].[dbo].[country] SET [name] = 'Eritrea' ,riskFactor = 4 WHERE idCountry = 18
UPDATE [eucomply].[dbo].[country] SET [name] = 'Guinea-Bissau' ,riskFactor = 4 WHERE idCountry = 19
UPDATE [eucomply].[dbo].[country] SET [name] = 'Zimbabwe' ,riskFactor = 6 WHERE idCountry = 20
UPDATE [eucomply].[dbo].[country] SET [name] = 'Syria' ,riskFactor = 7 WHERE idCountry = 21
UPDATE [eucomply].[dbo].[country] SET [name] = 'Congo Republic' ,riskFactor = 3 WHERE idCountry = 22
UPDATE [eucomply].[dbo].[country] SET [name] = 'Laos' ,riskFactor = 3 WHERE idCountry = 23
UPDATE [eucomply].[dbo].[country] SET [name] = 'Tajikistan' ,riskFactor = 3 WHERE idCountry = 24
UPDATE [eucomply].[dbo].[country] SET [name] = 'Central African Republic' ,riskFactor = 4 WHERE idCountry = 25
UPDATE [eucomply].[dbo].[country] SET [name] = 'Guinea' ,riskFactor = 4 WHERE idCountry = 26
UPDATE [eucomply].[dbo].[country] SET [name] = 'Papua New Guinea' ,riskFactor = 3 WHERE idCountry = 27
UPDATE [eucomply].[dbo].[country] SET [name] = 'Paraguay' ,riskFactor = 3 WHERE idCountry = 28
UPDATE [eucomply].[dbo].[country] SET [name] = 'Bangladesh' ,riskFactor = 3 WHERE idCountry = 29
UPDATE [eucomply].[dbo].[country] SET [name] = 'Cameroon' ,riskFactor = 3 WHERE idCountry = 30
UPDATE [eucomply].[dbo].[country] SET [name] = 'Kenya' ,riskFactor = 3 WHERE idCountry = 31
UPDATE [eucomply].[dbo].[country] SET [name] = 'Kyrgyzstan' ,riskFactor = 3 WHERE idCountry = 32
UPDATE [eucomply].[dbo].[country] SET [name] = 'Nigeria' ,riskFactor = 3 WHERE idCountry = 33
UPDATE [eucomply].[dbo].[country] SET [name] = 'Ukraine' ,riskFactor = 5 WHERE idCountry = 34
UPDATE [eucomply].[dbo].[country] SET [name] = 'Comoros' ,riskFactor = 3 WHERE idCountry = 35
UPDATE [eucomply].[dbo].[country] SET [name] = 'Iran' ,riskFactor = 9 WHERE idCountry = 36
UPDATE [eucomply].[dbo].[country] SET [name] = 'Uganda' ,riskFactor = 6 WHERE idCountry = 37
UPDATE [eucomply].[dbo].[country] SET [name] = 'Kazakhstan' ,riskFactor = 3 WHERE idCountry = 38
UPDATE [eucomply].[dbo].[country] SET [name] = 'Lebanon' ,riskFactor = 4 WHERE idCountry = 39
UPDATE [eucomply].[dbo].[country] SET [name] = 'Nicaragua' ,riskFactor = 6 WHERE idCountry = 40
UPDATE [eucomply].[dbo].[country] SET [name] = 'Russia' ,riskFactor = 9 WHERE idCountry = 41
UPDATE [eucomply].[dbo].[country] SET [name] = 'Azerbaijan' ,riskFactor = 4 WHERE idCountry = 42
UPDATE [eucomply].[dbo].[country] SET [name] = 'Guyana' ,riskFactor = 3 WHERE idCountry = 43
UPDATE [eucomply].[dbo].[country] SET [name] = 'Honduras' ,riskFactor = 3 WHERE idCountry = 44
UPDATE [eucomply].[dbo].[country] SET [name] = 'Madagascar' ,riskFactor = 3 WHERE idCountry = 45
UPDATE [eucomply].[dbo].[country] SET [name] = 'Nepal' ,riskFactor = 3 WHERE idCountry = 46
UPDATE [eucomply].[dbo].[country] SET [name] = 'Pakistan' ,riskFactor = 6 WHERE idCountry = 47
UPDATE [eucomply].[dbo].[country] SET [name] = 'Cote d Ivoire' ,riskFactor = 3 WHERE idCountry = 48
UPDATE [eucomply].[dbo].[country] SET [name] = 'Gambia' ,riskFactor = 3 WHERE idCountry = 49
UPDATE [eucomply].[dbo].[country] SET [name] = 'Guatemala' ,riskFactor = 3 WHERE idCountry = 50
UPDATE [eucomply].[dbo].[country] SET [name] = 'Mali' ,riskFactor = 6 WHERE idCountry = 51
UPDATE [eucomply].[dbo].[country] SET [name] = 'Sierra Leone' ,riskFactor = 3 WHERE idCountry = 52
UPDATE [eucomply].[dbo].[country] SET [name] = 'Timor-Leste' ,riskFactor = 3 WHERE idCountry = 53
UPDATE [eucomply].[dbo].[country] SET [name] = 'Togo' ,riskFactor = 3 WHERE idCountry = 54
UPDATE [eucomply].[dbo].[country] SET [name] = 'Belarus' ,riskFactor = 4 WHERE idCountry = 55
UPDATE [eucomply].[dbo].[country] SET [name] = 'Dominican Republic' ,riskFactor = 3 WHERE idCountry = 56
UPDATE [eucomply].[dbo].[country] SET [name] = 'Mauritania' ,riskFactor = 3 WHERE idCountry = 57
UPDATE [eucomply].[dbo].[country] SET [name] = 'Mozambique' ,riskFactor = 6 WHERE idCountry = 58
UPDATE [eucomply].[dbo].[country] SET [name] = 'Vietnam' ,riskFactor = 3 WHERE idCountry = 59
UPDATE [eucomply].[dbo].[country] SET [name] = 'Tanzania' ,riskFactor = 5 WHERE idCountry = 60
UPDATE [eucomply].[dbo].[country] SET [name] = 'Albania' ,riskFactor = 6 WHERE idCountry = 61
UPDATE [eucomply].[dbo].[country] SET [name] = 'Ecuador' ,riskFactor = 3 WHERE idCountry = 62
UPDATE [eucomply].[dbo].[country] SET [name] = 'Ethiopia' ,riskFactor = 4 WHERE idCountry = 63
UPDATE [eucomply].[dbo].[country] SET [name] = 'Kosovo' ,riskFactor = 3 WHERE idCountry = 64
UPDATE [eucomply].[dbo].[country] SET [name] = 'Argentina' ,riskFactor = 3 WHERE idCountry = 65
UPDATE [eucomply].[dbo].[country] SET [name] = 'Bolivia' ,riskFactor = 3 WHERE idCountry = 66
UPDATE [eucomply].[dbo].[country] SET [name] = 'Egypt' ,riskFactor = 4 WHERE idCountry = 67
UPDATE [eucomply].[dbo].[country] SET [name] = 'Indonesia' ,riskFactor = 3 WHERE idCountry = 68
UPDATE [eucomply].[dbo].[country] SET [name] = 'Malawi' ,riskFactor = 3 WHERE idCountry = 69
UPDATE [eucomply].[dbo].[country] SET [name] = 'Niger' ,riskFactor = 3 WHERE idCountry = 70
UPDATE [eucomply].[dbo].[country] SET [name] = 'Djibouti' ,riskFactor = 3 WHERE idCountry = 71
UPDATE [eucomply].[dbo].[country] SET [name] = 'Gabon' ,riskFactor = 3 WHERE idCountry = 72
UPDATE [eucomply].[dbo].[country] SET [name] = 'Mexico' ,riskFactor = 2 WHERE idCountry = 73
UPDATE [eucomply].[dbo].[country] SET [name] = 'Moldova' ,riskFactor = 3 WHERE idCountry = 74
UPDATE [eucomply].[dbo].[country] SET [name] = 'Philippines' ,riskFactor = 6 WHERE idCountry = 75
UPDATE [eucomply].[dbo].[country] SET [name] = 'Algeria' ,riskFactor = 3 WHERE idCountry = 76
UPDATE [eucomply].[dbo].[country] SET [name] = 'Armenia' ,riskFactor = 4 WHERE idCountry = 77
UPDATE [eucomply].[dbo].[country] SET [name] = 'Panama' ,riskFactor = 6 WHERE idCountry = 78
UPDATE [eucomply].[dbo].[country] SET [name] = 'Suriname' ,riskFactor = 3 WHERE idCountry = 79
UPDATE [eucomply].[dbo].[country] SET [name] = 'Thailand' ,riskFactor = 3 WHERE idCountry = 80
UPDATE [eucomply].[dbo].[country] SET [name] = 'Benin' ,riskFactor = 3 WHERE idCountry = 81
UPDATE [eucomply].[dbo].[country] SET [name] = 'China' ,riskFactor = 3 WHERE idCountry = 82
UPDATE [eucomply].[dbo].[country] SET [name] = 'Colombia' ,riskFactor = 2 WHERE idCountry = 83
UPDATE [eucomply].[dbo].[country] SET [name] = 'India' ,riskFactor = 3 WHERE idCountry = 84
UPDATE [eucomply].[dbo].[country] SET [name] = 'Mongolia' ,riskFactor = 4 WHERE idCountry = 85
UPDATE [eucomply].[dbo].[country] SET [name] = 'Morocco' ,riskFactor = 6 WHERE idCountry = 86
UPDATE [eucomply].[dbo].[country] SET [name] = 'Peru' ,riskFactor = 3 WHERE idCountry = 87
UPDATE [eucomply].[dbo].[country] SET [name] = 'Burkina Faso' ,riskFactor = 5 WHERE idCountry = 88
UPDATE [eucomply].[dbo].[country] SET [name] = 'Zambia' ,riskFactor = 3 WHERE idCountry = 89
UPDATE [eucomply].[dbo].[country] SET [name] = 'El Salvador' ,riskFactor = 3 WHERE idCountry = 90
UPDATE [eucomply].[dbo].[country] SET [name] = 'Jamaica' ,riskFactor = 6 WHERE idCountry = 91
UPDATE [eucomply].[dbo].[country] SET [name] = 'Liberia' ,riskFactor = 4 WHERE idCountry = 92
UPDATE [eucomply].[dbo].[country] SET [name] = 'Sri Lanka' ,riskFactor = 3 WHERE idCountry = 93
UPDATE [eucomply].[dbo].[country] SET [name] = 'Trinidad and Tobago' ,riskFactor = 6 WHERE idCountry = 94
UPDATE [eucomply].[dbo].[country] SET [name] = 'Bosnia and Herzegovina' ,riskFactor = 4 WHERE idCountry = 95
UPDATE [eucomply].[dbo].[country] SET [name] = 'Brazil' ,riskFactor = 3 WHERE idCountry = 96
UPDATE [eucomply].[dbo].[country] SET [name] = 'Senegal' ,riskFactor = 5 WHERE idCountry = 97
UPDATE [eucomply].[dbo].[country] SET [name] = 'Tunisia' ,riskFactor = 4 WHERE idCountry = 98
UPDATE [eucomply].[dbo].[country] SET [name] = 'Serbia' ,riskFactor = 3 WHERE idCountry = 99
UPDATE [eucomply].[dbo].[country] SET [name] = 'Bulgaria' ,riskFactor = 1 WHERE idCountry = 100
UPDATE [eucomply].[dbo].[country] SET [name] = 'Greece' ,riskFactor = 1 WHERE idCountry = 101
UPDATE [eucomply].[dbo].[country] SET [name] = 'Sao Tome and Principe' ,riskFactor = 3 WHERE idCountry = 102
UPDATE [eucomply].[dbo].[country] SET [name] = 'Italy' ,riskFactor = 1 WHERE idCountry = 103
UPDATE [eucomply].[dbo].[country] SET [name] = 'Montenegro' ,riskFactor = 3 WHERE idCountry = 104
UPDATE [eucomply].[dbo].[country] SET [name] = 'South Africa' ,riskFactor = 3 WHERE idCountry = 105
UPDATE [eucomply].[dbo].[country] SET [name] = 'Romania' ,riskFactor = 2 WHERE idCountry = 106
UPDATE [eucomply].[dbo].[country] SET [name] = 'Ghana' ,riskFactor = 3 WHERE idCountry = 107
UPDATE [eucomply].[dbo].[country] SET [name] = 'Kuwait' ,riskFactor = 3 WHERE idCountry = 108
UPDATE [eucomply].[dbo].[country] SET [name] = 'Oman' ,riskFactor = 4 WHERE idCountry = 109
UPDATE [eucomply].[dbo].[country] SET [name] = 'Cuba' ,riskFactor = 4 WHERE idCountry = 110
UPDATE [eucomply].[dbo].[country] SET [name] = 'Lesotho' ,riskFactor = 3 WHERE idCountry = 111
UPDATE [eucomply].[dbo].[country] SET [name] = 'Turkey' ,riskFactor = 6 WHERE idCountry = 112
UPDATE [eucomply].[dbo].[country] SET [name] = 'Croatia' ,riskFactor = 2 WHERE idCountry = 113
UPDATE [eucomply].[dbo].[country] SET [name] = 'Jordan' ,riskFactor = 5 WHERE idCountry = 114
UPDATE [eucomply].[dbo].[country] SET [name] = 'Namibia' ,riskFactor = 3 WHERE idCountry = 115
UPDATE [eucomply].[dbo].[country] SET [name] = 'Saudi Arabia' ,riskFactor = 3 WHERE idCountry = 116
UPDATE [eucomply].[dbo].[country] SET [name] = 'Slovakia' ,riskFactor = 1 WHERE idCountry = 117
UPDATE [eucomply].[dbo].[country] SET [name] = 'Bahrain' ,riskFactor = 3 WHERE idCountry = 118
UPDATE [eucomply].[dbo].[country] SET [name] = 'Malaysia' ,riskFactor = 3 WHERE idCountry = 119
UPDATE [eucomply].[dbo].[country] SET [name] = 'Georgia' ,riskFactor = 3 WHERE idCountry = 120
UPDATE [eucomply].[dbo].[country] SET [name] = 'Czech Republic' ,riskFactor = 1 WHERE idCountry = 121
UPDATE [eucomply].[dbo].[country] SET [name] = 'Hungary' ,riskFactor = 1 WHERE idCountry = 122
UPDATE [eucomply].[dbo].[country] SET [name] = 'Latvia' ,riskFactor = 1 WHERE idCountry = 123
UPDATE [eucomply].[dbo].[country] SET [name] = 'Rwanda' ,riskFactor = 3 WHERE idCountry = 124
UPDATE [eucomply].[dbo].[country] SET [name] = 'Mauritius' ,riskFactor = 3 WHERE idCountry = 125
UPDATE [eucomply].[dbo].[country] SET [name] = 'Seychelles' ,riskFactor = 3 WHERE idCountry = 126
UPDATE [eucomply].[dbo].[country] SET [name] = 'Costa Rica' ,riskFactor = 2 WHERE idCountry = 127
UPDATE [eucomply].[dbo].[country] SET [name] = 'Korea (South)' ,riskFactor = 2 WHERE idCountry = 128
UPDATE [eucomply].[dbo].[country] SET [name] = 'Malta' ,riskFactor = 2 WHERE idCountry = 129
UPDATE [eucomply].[dbo].[country] SET [name] = 'Cape Verde' ,riskFactor = 3 WHERE idCountry = 130
UPDATE [eucomply].[dbo].[country] SET [name] = 'Lithuania' ,riskFactor = 1 WHERE idCountry = 131
UPDATE [eucomply].[dbo].[country] SET [name] = 'Slovenia' ,riskFactor = 1 WHERE idCountry = 132
UPDATE [eucomply].[dbo].[country] SET [name] = 'Israel' ,riskFactor = 2 WHERE idCountry = 133
UPDATE [eucomply].[dbo].[country] SET [name] = 'Poland' ,riskFactor = 1 WHERE idCountry = 134
UPDATE [eucomply].[dbo].[country] SET [name] = 'Spain' ,riskFactor = 1 WHERE idCountry = 135
UPDATE [eucomply].[dbo].[country] SET [name] = 'Taiwan' ,riskFactor = 3 WHERE idCountry = 136
UPDATE [eucomply].[dbo].[country] SET [name] = 'Cyprus' ,riskFactor = 0 WHERE idCountry = 137
UPDATE [eucomply].[dbo].[country] SET [name] = 'Portugal' ,riskFactor = 1 WHERE idCountry = 138
UPDATE [eucomply].[dbo].[country] SET [name] = 'Bhutan' ,riskFactor = 2 WHERE idCountry = 139
UPDATE [eucomply].[dbo].[country] SET [name] = 'Botswana' ,riskFactor = 3 WHERE idCountry = 140
UPDATE [eucomply].[dbo].[country] SET [name] = 'Estonia' ,riskFactor = 1 WHERE idCountry = 141
UPDATE [eucomply].[dbo].[country] SET [name] = 'United Arab Emirates' ,riskFactor = 5 WHERE idCountry = 142
UPDATE [eucomply].[dbo].[country] SET [name] = 'France' ,riskFactor = 1 WHERE idCountry = 143
UPDATE [eucomply].[dbo].[country] SET [name] = 'Qatar' ,riskFactor = 3 WHERE idCountry = 144
UPDATE [eucomply].[dbo].[country] SET [name] = 'Chile' ,riskFactor = 2 WHERE idCountry = 145
UPDATE [eucomply].[dbo].[country] SET [name] = 'Austria' ,riskFactor = 1 WHERE idCountry = 146
UPDATE [eucomply].[dbo].[country] SET [name] = 'Uruguay' ,riskFactor = 3 WHERE idCountry = 147
UPDATE [eucomply].[dbo].[country] SET [name] = 'Ireland' ,riskFactor = 1 WHERE idCountry = 148
UPDATE [eucomply].[dbo].[country] SET [name] = 'United States of America (USA)' ,riskFactor = 2 WHERE idCountry = 149
UPDATE [eucomply].[dbo].[country] SET [name] = 'Hong Kong' ,riskFactor = 3 WHERE idCountry = 150
UPDATE [eucomply].[dbo].[country] SET [name] = 'Japan' ,riskFactor = 2 WHERE idCountry = 151
UPDATE [eucomply].[dbo].[country] SET [name] = 'Belgium' ,riskFactor = 1 WHERE idCountry = 152
UPDATE [eucomply].[dbo].[country] SET [name] = 'United Kingdom (UK)' ,riskFactor = 2 WHERE idCountry = 153
UPDATE [eucomply].[dbo].[country] SET [name] = 'Germany' ,riskFactor = 1 WHERE idCountry = 154
UPDATE [eucomply].[dbo].[country] SET [name] = 'Iceland' ,riskFactor = 2 WHERE idCountry = 155
UPDATE [eucomply].[dbo].[country] SET [name] = 'Luxembourg' ,riskFactor = 1 WHERE idCountry = 156
UPDATE [eucomply].[dbo].[country] SET [name] = 'Australia' ,riskFactor = 2 WHERE idCountry = 157
UPDATE [eucomply].[dbo].[country] SET [name] = 'Canada' ,riskFactor = 2 WHERE idCountry = 158
UPDATE [eucomply].[dbo].[country] SET [name] = 'Netherlands' ,riskFactor = 1 WHERE idCountry = 159
UPDATE [eucomply].[dbo].[country] SET [name] = 'Norway' ,riskFactor = 1 WHERE idCountry = 160
UPDATE [eucomply].[dbo].[country] SET [name] = 'Singapore' ,riskFactor = 2 WHERE idCountry = 161
UPDATE [eucomply].[dbo].[country] SET [name] = 'Switzerland' ,riskFactor = 2 WHERE idCountry = 162
UPDATE [eucomply].[dbo].[country] SET [name] = 'Sweden' ,riskFactor = 1 WHERE idCountry = 163
UPDATE [eucomply].[dbo].[country] SET [name] = 'New Zealand' ,riskFactor = 1 WHERE idCountry = 164
UPDATE [eucomply].[dbo].[country] SET [name] = 'Finland' ,riskFactor = 1 WHERE idCountry = 165
UPDATE [eucomply].[dbo].[country] SET [name] = 'Denmark' ,riskFactor = 1 WHERE idCountry = 166
UPDATE [eucomply].[dbo].[country] SET [name] = 'Andorra' ,riskFactor = 3 WHERE idCountry = 167
UPDATE [eucomply].[dbo].[country] SET [name] = 'Anguilla' ,riskFactor = 3 WHERE idCountry = 168
UPDATE [eucomply].[dbo].[country] SET [name] = 'Antigua and Bermuda' ,riskFactor = 3 WHERE idCountry = 169
UPDATE [eucomply].[dbo].[country] SET [name] = 'Aruba' ,riskFactor = 3 WHERE idCountry = 170
UPDATE [eucomply].[dbo].[country] SET [name] = 'Bahamas' ,riskFactor = 3 WHERE idCountry = 171
UPDATE [eucomply].[dbo].[country] SET [name] = 'Barbados' ,riskFactor = 6 WHERE idCountry = 172
UPDATE [eucomply].[dbo].[country] SET [name] = 'Belize' ,riskFactor = 4 WHERE idCountry = 173
UPDATE [eucomply].[dbo].[country] SET [name] = 'Bermuda' ,riskFactor = 3 WHERE idCountry = 174
UPDATE [eucomply].[dbo].[country] SET [name] = 'Virgin Islands (British)' ,riskFactor = 3 WHERE idCountry = 175
UPDATE [eucomply].[dbo].[country] SET [name] = 'Brunei' ,riskFactor = 3 WHERE idCountry = 176
UPDATE [eucomply].[dbo].[country] SET [name] = 'Cayman Islands' ,riskFactor = 6 WHERE idCountry = 177
UPDATE [eucomply].[dbo].[country] SET [name] = 'Cook Islands' ,riskFactor = 3 WHERE idCountry = 178
UPDATE [eucomply].[dbo].[country] SET [name] = 'Dominica' ,riskFactor = 3 WHERE idCountry = 179
UPDATE [eucomply].[dbo].[country] SET [name] = 'Equatorial Guinea' ,riskFactor = 3 WHERE idCountry = 180
UPDATE [eucomply].[dbo].[country] SET [name] = 'Fiji' ,riskFactor = 4 WHERE idCountry = 181
UPDATE [eucomply].[dbo].[country] SET [name] = 'Gibraltar' ,riskFactor = 5 WHERE idCountry = 182
UPDATE [eucomply].[dbo].[country] SET [name] = 'Granada' ,riskFactor = 3 WHERE idCountry = 183
UPDATE [eucomply].[dbo].[country] SET [name] = 'Grenada' ,riskFactor = 3 WHERE idCountry = 184
UPDATE [eucomply].[dbo].[country] SET [name] = 'Guernsey' ,riskFactor = 3 WHERE idCountry = 185
UPDATE [eucomply].[dbo].[country] SET [name] = 'Holy see' ,riskFactor = 3 WHERE idCountry = 186
UPDATE [eucomply].[dbo].[country] SET [name] = 'Isle of Man' ,riskFactor = 3 WHERE idCountry = 187
UPDATE [eucomply].[dbo].[country] SET [name] = 'Jersey' ,riskFactor = 3 WHERE idCountry = 188
UPDATE [eucomply].[dbo].[country] SET [name] = 'Liechtenstein' ,riskFactor = 3 WHERE idCountry = 189
UPDATE [eucomply].[dbo].[country] SET [name] = 'Macau' ,riskFactor = 3 WHERE idCountry = 190
UPDATE [eucomply].[dbo].[country] SET [name] = 'North Macedonia' ,riskFactor = 3 WHERE idCountry = 191
UPDATE [eucomply].[dbo].[country] SET [name] = 'Marshall Islands' ,riskFactor = 3 WHERE idCountry = 192
UPDATE [eucomply].[dbo].[country] SET [name] = 'Monaco' ,riskFactor = 3 WHERE idCountry = 193
UPDATE [eucomply].[dbo].[country] SET [name] = 'Niue' ,riskFactor = 3 WHERE idCountry = 194
UPDATE [eucomply].[dbo].[country] SET [name] = 'Samoa' ,riskFactor = 4 WHERE idCountry = 195
UPDATE [eucomply].[dbo].[country] SET [name] = 'San Marino' ,riskFactor = 3 WHERE idCountry = 196
UPDATE [eucomply].[dbo].[country] SET [name] = 'Sint Martin' ,riskFactor = 3 WHERE idCountry = 197
UPDATE [eucomply].[dbo].[country] SET [name] = 'Solomon Islands' ,riskFactor = 3 WHERE idCountry = 198
UPDATE [eucomply].[dbo].[country] SET [name] = 'St. Kitts and Nevis' ,riskFactor = 3 WHERE idCountry = 199
UPDATE [eucomply].[dbo].[country] SET [name] = 'St. Lucia' ,riskFactor = 3 WHERE idCountry = 200
UPDATE [eucomply].[dbo].[country] SET [name] = 'St. Vincent and the Grenadines' ,riskFactor = 3 WHERE idCountry = 201
UPDATE [eucomply].[dbo].[country] SET [name] = 'Turks and Caicos Islands' ,riskFactor = 3 WHERE idCountry = 202
UPDATE [eucomply].[dbo].[country] SET [name] = 'Vanuatu' ,riskFactor = 4 WHERE idCountry = 203
UPDATE [eucomply].[dbo].[country] SET [name] = 'Maldives' ,riskFactor = 4 WHERE idCountry = 204
UPDATE [eucomply].[dbo].[country] SET [name] = 'Montserrat' ,riskFactor = 3 WHERE idCountry = 205
UPDATE [eucomply].[dbo].[country] SET [name] = 'Nauru' ,riskFactor = 3 WHERE idCountry = 206
UPDATE [eucomply].[dbo].[country] SET [name] = 'Palau' ,riskFactor = 3 WHERE idCountry = 207
UPDATE [eucomply].[dbo].[country] SET [name] = 'Saint Kids and Nevis' ,riskFactor = 3 WHERE idCountry = 208
UPDATE [eucomply].[dbo].[country] SET [name] = 'Saint Lucia' ,riskFactor = 3 WHERE idCountry = 209
UPDATE [eucomply].[dbo].[country] SET [name] = 'Tuvalu' ,riskFactor = 3 WHERE idCountry = 210
UPDATE [eucomply].[dbo].[country] SET [name] = 'Channel Islands' ,riskFactor = 3 WHERE idCountry = 211
UPDATE [eucomply].[dbo].[country] SET [name] = 'NOT AVAILABLE' ,riskFactor = 9 WHERE idCountry = 212
UPDATE [eucomply].[dbo].[country] SET [name] = 'Curacao' ,riskFactor = 3 WHERE idCountry = 213
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE; BEGIN TRANSACTION; UPDATE [eucomply].dbo.country SET [name] = 'American Samoa',riskFactor = 9 WHERE idCountry = 214; IF @@ROWCOUNT = 0 BEGIN SET IDENTITY_INSERT [eucomply].[dbo].[country] ON; INSERT INTO [eucomply].[dbo].[country] ([idCountry], name, riskFactor) VALUES('214','American Samoa','9'); SET IDENTITY_INSERT [eucomply].[dbo].[country] OFF; END COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE; BEGIN TRANSACTION; UPDATE [eucomply].dbo.country SET [name] = 'Guam',riskFactor = 9 WHERE idCountry = 215; IF @@ROWCOUNT = 0 BEGIN SET IDENTITY_INSERT [eucomply].[dbo].[country] ON; INSERT INTO [eucomply].[dbo].[country] ([idCountry], name, riskFactor) VALUES('215','Guam','9'); SET IDENTITY_INSERT [eucomply].[dbo].[country] OFF; END COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE; BEGIN TRANSACTION; UPDATE [eucomply].dbo.country SET [name] = 'Puerto Rico',riskFactor = 9 WHERE idCountry = 216; IF @@ROWCOUNT = 0 BEGIN SET IDENTITY_INSERT [eucomply].[dbo].[country] ON; INSERT INTO [eucomply].[dbo].[country] ([idCountry], name, riskFactor) VALUES('216','Puerto Rico','9'); SET IDENTITY_INSERT [eucomply].[dbo].[country] OFF; END COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE; BEGIN TRANSACTION; UPDATE [eucomply].dbo.country SET [name] = 'Eswatini (Swaziland)',riskFactor = 9 WHERE idCountry = 217; IF @@ROWCOUNT = 0 BEGIN SET IDENTITY_INSERT [eucomply].[dbo].[country] ON; INSERT INTO [eucomply].[dbo].[country] ([idCountry], name, riskFactor) VALUES('217','Eswatini (Swaziland)','9'); SET IDENTITY_INSERT [eucomply].[dbo].[country] OFF; END COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE; BEGIN TRANSACTION; UPDATE [eucomply].dbo.country SET [name] = 'Virgin Islands (U.S.)',riskFactor = 9 WHERE idCountry = 218; IF @@ROWCOUNT = 0 BEGIN SET IDENTITY_INSERT [eucomply].[dbo].[country] ON; INSERT INTO [eucomply].[dbo].[country] ([idCountry], name, riskFactor) VALUES('218','Virgin Islands (U.S.)','9'); SET IDENTITY_INSERT [eucomply].[dbo].[country] OFF; END COMMIT TRANSACTION;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE; BEGIN TRANSACTION; UPDATE [eucomply].dbo.country SET [name] = 'Congo, Democratic Republic of',riskFactor = 5 WHERE idCountry = 220; IF @@ROWCOUNT = 0 BEGIN SET IDENTITY_INSERT [eucomply].[dbo].[country] ON; INSERT INTO [eucomply].[dbo].[country] ([idCountry], name, riskFactor) VALUES('220','Congo, Democratic Republic of','5'); SET IDENTITY_INSERT [eucomply].[dbo].[country] OFF; END COMMIT TRANSACTION;
